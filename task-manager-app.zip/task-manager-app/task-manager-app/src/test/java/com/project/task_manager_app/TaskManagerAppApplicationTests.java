package com.project.task_manager_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
