package com.project.task_manager_app.exception;

import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND) // This makes Spring return a 404 Not Found status

public class TaskNotFoundException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TaskNotFoundException(String message) {

        super(message);

    }

}