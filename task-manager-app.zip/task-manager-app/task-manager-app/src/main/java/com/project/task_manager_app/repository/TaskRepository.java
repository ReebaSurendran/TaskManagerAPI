package com.project.task_manager_app.repository;

import com.project.task_manager_app.model.Task;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class TaskRepository {

	// (K:V) = (Task Id:Task Object)
    private final ConcurrentHashMap<Long, Task> tasks = new ConcurrentHashMap<>();

    public TaskRepository() {
        save(new Task("Read a Book", "Understand the new words", false));
        save(new Task("Learn a new Technology", "Try a project", false));
        save(new Task("Go for a Walk", "Get some fresh air.", true));
    }

    public List<Task> findAll() {
        return new ArrayList<>(tasks.values()); 
    }

    public Optional<Task> findById(Long id) {
        return Optional.ofNullable(tasks.get(id));
    }

    public Task save(Task task) {
        tasks.put(task.getId(), task);
        return task;
    }

    public void deleteById(Long id) {
        tasks.remove(id);
    }

    public boolean existsById(Long id) {
        return tasks.containsKey(id);
    }
}